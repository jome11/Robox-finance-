import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'package:intl/intl.dart';
import '../models/transaction_model.dart';
import '../providers/finance_provider.dart';
import '../../../core/theme/app_theme.dart';

class AddShipmentTransactionScreen extends StatefulWidget {
  const AddShipmentTransactionScreen({super.key});

  @override
  State<AddShipmentTransactionScreen> createState() => _AddShipmentTransactionScreenState();
}

class _AddShipmentTransactionScreenState extends State<AddShipmentTransactionScreen> {
  final _formKey = GlobalKey<FormState>();
  String _shipmentNumber = '';
  String _title = '';
  double _amount = 0.0;
  String _type = 'expense'; // 'income' or 'expense'
  String _paymentMethod = 'Telebirr';
  DateTime _date = DateTime.now();
  String _note = '';
  final List<String> _imagePaths = [];

  final ImagePicker _picker = ImagePicker();

  final List<String> _paymentMethods = [
    'Telebirr',
    'CBE',
    'Other Bank',
    'Cash',
  ];

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(source: source, imageQuality: 85);
      if (pickedFile != null) {
        final compressedPath = await _compressAndSaveImage(pickedFile.path);
        setState(() {
          _imagePaths.add(compressedPath);
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error picking image: $e'), backgroundColor: AppTheme.dangerRed),
        );
      }
    }
  }

  Future<String> _compressAndSaveImage(String originalPath) async {
    try {
      final bytes = await File(originalPath).readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image != null) {
        img.Image resized = img.copyResize(image, width: 1024);
        final compressedBytes = img.encodeJpg(resized, quality: 80);
        
        final tempDir = Directory.systemTemp;
        final targetPath = '${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg';
        final targetFile = File(targetPath);
        await targetFile.writeAsBytes(compressedBytes);
        return targetPath;
      }
    } catch (_) {}
    return originalPath;
  }

  void _showFullScreenImage(String path) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: EdgeInsets.zero,
        child: Stack(
          alignment: Alignment.center,
          children: [
            InteractiveViewer(
              child: Image.file(File(path)),
            ),
            Positioned(
              top: 40,
              right: 20,
              child: IconButton(
                icon: const Icon(Icons.close, color: Colors.white, size: 30),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _saveForm() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final provider = Provider.of<FinanceProvider>(context, listen: false);

      final newTransaction = TransactionModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: _title,
        amount: _amount,
        category: _type == 'income' ? 'Shipment Income' : 'Shipment Expense',
        subcategory: 'Shipment',
        paymentMethod: _paymentMethod,
        date: _date,
        note: _note,
        imagePaths: _imagePaths,
        type: _type,
        shipmentNumber: _shipmentNumber.trim(),
      );

      provider.addTransaction(newTransaction);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Shipment Transaction'),
        actions: [
          IconButton(
            icon: const Icon(Icons.check, color: AppTheme.primaryBlue),
            onPressed: _saveForm,
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Shipment Type Selector (Income vs Expense)
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'expense', label: Text('Shipment Expense'), icon: Icon(Icons.arrow_upward)),
                ButtonSegment(value: 'income', label: Text('Shipment Income'), icon: Icon(Icons.arrow_downward)),
              ],
              selected: {_type},
              onSelectionChanged: (val) {
                setState(() {
                  _type = val.first;
                });
              },
            ),
            const SizedBox(height: 20),
            // Shipment ID / Number (Required)
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'Shipment Number / ID (Required)',
                prefixIcon: Icon(Icons.local_shipping, color: AppTheme.primaryBlue),
                hintText: 'e.g. SHP-2026-001',
              ),
              validator: (value) => value == null || value.trim().isEmpty ? 'Please enter a shipment number' : null,
              onSaved: (value) => _shipmentNumber = value ?? '',
            ),
            const SizedBox(height: 16),
            // Title
            TextFormField(
              decoration: const InputDecoration(labelText: 'Title / Description', prefixIcon: Icon(Icons.title)),
              validator: (value) => value == null || value.isEmpty ? 'Please enter a title' : null,
              onSaved: (value) => _title = value ?? '',
            ),
            const SizedBox(height: 16),
            // Amount
            TextFormField(
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Amount (Br)', prefixIcon: Icon(Icons.money)),
              validator: (value) {
                if (value == null || double.tryParse(value) == null || double.parse(value) <= 0) {
                  return 'Please enter a valid amount';
                }
                return null;
              },
              onSaved: (value) => _amount = double.parse(value!),
            ),
            const SizedBox(height: 16),
            // Payment Method
            DropdownButtonFormField<String>(
              isDense: true,
              value: _paymentMethods.first,
              decoration: const InputDecoration(
                labelText: 'Payment Method',
                prefixIcon: Icon(Icons.payment, size: 20),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              ),
              items: _paymentMethods.map((p) => DropdownMenuItem(
                value: p,
                child: Text(p, style: const TextStyle(fontSize: 14)),
              )).toList(),
              onChanged: (val) => setState(() => _paymentMethod = val ?? _paymentMethods.first),
            ),
            const SizedBox(height: 16),
            // Date Picker
            InkWell(
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: _date,
                  firstDate: DateTime(2020),
                  lastDate: DateTime(2100),
                );
                if (picked != null) {
                  setState(() => _date = picked);
                }
              },
              child: InputDecorator(
                decoration: const InputDecoration(labelText: 'Date', prefixIcon: Icon(Icons.calendar_today)),
                child: Text(DateFormat('yyyy-MM-dd').format(_date)),
              ),
            ),
            const SizedBox(height: 16),
            // Note
            TextFormField(
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Note (Optional)', prefixIcon: Icon(Icons.note)),
              onSaved: (value) => _note = value ?? '',
            ),
            const SizedBox(height: 24),
            const Text('Image Attachments', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: () => _pickImage(ImageSource.gallery),
                  icon: const Icon(Icons.photo_library),
                  label: const Text('Gallery'),
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: () => _pickImage(ImageSource.camera),
                  icon: const Icon(Icons.camera_alt),
                  label: const Text('Camera'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (_imagePaths.isNotEmpty)
              SizedBox(
                height: 100,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _imagePaths.length,
                  itemBuilder: (context, index) {
                    final path = _imagePaths[index];
                    return Container(
                      margin: const EdgeInsets.only(right: 12),
                      width: 100,
                      height: 100,
                      child: Stack(
                        children: [
                          GestureDetector(
                            onTap: () => _showFullScreenImage(path),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.file(
                                File(path),
                                width: 100,
                                height: 100,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Positioned(
                            top: 4,
                            right: 4,
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  _imagePaths.removeAt(index);
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.all(4),
                                decoration: const BoxDecoration(
                                  color: AppTheme.dangerRed,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.close, size: 14, color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 40),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryBlue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: _saveForm,
              child: const Text('Save Shipment Transaction', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
